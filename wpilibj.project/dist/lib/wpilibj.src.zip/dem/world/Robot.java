/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dem.world;

/**
 *
 * @author Evan Coleman
 */
public class Robot {
    float x,y,z;
    
    public Robot(float x, float y, float z) {
     this.x = x;
     this.y = y;
     this.z = z;
    }
}